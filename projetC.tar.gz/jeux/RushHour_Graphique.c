#include "piece.h"
#include "game.h"
#include "stdbool.h"
#include "stdlib.h"
#include "stdio.h"
#include <MLV/MLV_all.h>
#include <string.h>

#define TAILLE 6
#define ENTETE_V 100
#define ENTETE_H 220
#define TAILLE_BRIQUE 100
#define DECALAGE_NUM_H TAILLE_BRIQUE-10
#define DECALAGE_NUM_V TAILLE_BRIQUE/4
#define Y_SORTIE 3


/**
 * Affiche la grille de jeu dans la fenetre
 * On alterne entre des pièces claires et des pièces plus foncées en s'assurant que deux pièces 
 * de la même couleur ne peuvent pas se toucher pour réaliser un cadrillage correct
 */
void afficher_grille(int taille, int widthF, int heightF){

	int image_width = widthF, image_height = heightF;
	int brique_width, brique_height;	

	/** Chargement de l'image de fond de jeu **/
	MLV_Image *image_fond = MLV_load_image( "../../images/fond_jeu.png" );

	/** Chargement des images des différents type de briques qui vont constituer le cadrillage **/
	MLV_Image *briqueC = MLV_load_image( "../../images/brique_elementaire_c.png" );
	MLV_Image *briqueF = MLV_load_image( "../../images/brique_elementaire_f.png" );
	
	/** Redimensionnement de l'image de fond et des briques **/
	MLV_resize_image(image_fond, image_width, image_height);
	MLV_resize_image(briqueC, TAILLE_BRIQUE, TAILLE_BRIQUE);
	MLV_resize_image(briqueF, TAILLE_BRIQUE, TAILLE_BRIQUE);
	
	/** Récupération de la taille de l'image de fond et des briques **/
	MLV_get_image_size( image_fond, &image_width, &image_height );
	MLV_get_image_size( briqueC, &brique_width, &brique_height );

	/** Affichage de l'image de fond **/
	MLV_draw_image(image_fond,0,0);

	/** Affichage du cadrillage constitué des deux types de briques **/
	/** On s'occupe de cet affichage ligne par ligne, et on alterne à chaque fois la brique de départ 
		Pour ne pas avoir deux briques de la même couleurs collées l'une à l'autre **/	
	int brique=0;
	for(int i=0; i<taille; ++i){
		for(int j=0; j<taille; ++j){
			if((i%2)==0){
				if((brique%2)==0)
					MLV_draw_image(briqueC,j*brique_width,i*brique_height+ENTETE_V);
				else
					MLV_draw_image(briqueF,j*brique_width,i*brique_height+ENTETE_V);
				brique++;
			}
			else{
				if((brique%2)==0)
					MLV_draw_image(briqueF,j*brique_width,i*brique_height+ENTETE_V);
				else
					MLV_draw_image(briqueC,j*brique_width,i*brique_height+ENTETE_V);
				brique++;
			}
		}
	}

    /** On affiche les modifications effectuées **/ 
	MLV_actualise_window();


	/** Libération des images **/
	MLV_free_image( image_fond );
	MLV_free_image( briqueC );
	MLV_free_image( briqueF );

}

/**
 * Affiche les pièces (voitures) une à une sur la grille de jeu dans la fenetre
 * On traite l'affichage d'une pièce en regardant leur taille ainsi que leur forme
 * On traite aussi l'affichage du numéro de la pièce que l'on superpose à l'image de la pièce
 */
void afficher_voitures(game g){

	/** Chargement et redimensionnement des images correspondant au différents type de voitures **/
	MLV_Image *voiturePrincipale = MLV_load_image( "../../images/rh/vrh_p_rouge.png" );
	MLV_resize_image(voiturePrincipale, 200, 100);
	MLV_Image *voitureBleuH = MLV_load_image( "../../images/rh/vrh_p_bleu_h.png" );
	MLV_resize_image(voitureBleuH, 200, 100);
    MLV_Image *voitureBleuV = MLV_load_image( "../../images/rh/vrh_p_bleu_v.png" );
    MLV_resize_image(voitureBleuV, 100, 200);
    MLV_Image *voitureRoseH = MLV_load_image( "../../images/rh/vrh_p_rose_h.png" );
    MLV_resize_image(voitureRoseH, 300, 100);
    MLV_Image *voitureRoseV = MLV_load_image( "../../images/rh/vrh_p_rose_v.png" );
    MLV_resize_image(voitureRoseV, 100, 300);

    int x=0;
    int y=0;

    MLV_Font* font = MLV_load_font( "../../fonts/8-bit.ttf" , 20 );

    char str[2];

    /** Pour chaque pièce contenue dans le jeu **/
    for(int i=0; i<game_nb_pieces(g); ++i){

      x = get_x(game_piece(g,i));
      y = get_y(game_piece(g,i));
      str[0] = i+'0';
      str[1] = '\0';

      /** On traite différemment les cas suivants :
        -lorsque la voiture est la pièce principale
        -lorsque la pièce est petite et verticale
        -lorsque la pièce est grande et verticale
        -lorsque la pièce est petite et horizontale
        -lorsque la pièce est grande et horizontale
        Et on affiche une image différente dans chaque cas ainsi que son numéro **/
      if (i==0)
      {
            MLV_draw_image(voiturePrincipale,x*TAILLE_BRIQUE,(TAILLE-y-1)*TAILLE_BRIQUE+ENTETE_V);
            MLV_draw_text_with_font(
                x*TAILLE_BRIQUE+DECALAGE_NUM_H, (TAILLE-y-1)*TAILLE_BRIQUE+ENTETE_V+DECALAGE_NUM_V,
                str,
                font,
                MLV_COLOR_ANTIQUE_WHITE
            );
        }
        else if(!is_horizontal(game_piece(g,i)) && get_height(game_piece(g,i))==2){
           MLV_draw_image(voitureBleuV,x*TAILLE_BRIQUE,(TAILLE-y-2)*TAILLE_BRIQUE+ENTETE_V);
           MLV_draw_text_with_font(
                x*TAILLE_BRIQUE+DECALAGE_NUM_V*1.5, (TAILLE-y-2)*TAILLE_BRIQUE+ENTETE_V+DECALAGE_NUM_H,
                str,
                font,
                MLV_COLOR_ANTIQUE_WHITE
            );
        }
       else if(!is_horizontal(game_piece(g,i)) && get_height(game_piece(g,i))==3){
            MLV_draw_image(voitureRoseV,x*TAILLE_BRIQUE,(TAILLE-y-3)*TAILLE_BRIQUE+ENTETE_V);
            MLV_draw_text_with_font(
                x*TAILLE_BRIQUE+DECALAGE_NUM_V*1.5, (TAILLE-y-3)*TAILLE_BRIQUE+ENTETE_V+DECALAGE_NUM_H,
                str,
                font,
                MLV_COLOR_ANTIQUE_WHITE
            );
        }
        else if(get_width(game_piece(g,i))==3){
            MLV_draw_image(voitureRoseH,x*TAILLE_BRIQUE,(TAILLE-y-1)*TAILLE_BRIQUE+ENTETE_V);
            MLV_draw_text_with_font(
                x*TAILLE_BRIQUE+DECALAGE_NUM_H, (TAILLE-y-1)*TAILLE_BRIQUE+ENTETE_V+DECALAGE_NUM_V,
                str,
                font,
                MLV_COLOR_ANTIQUE_WHITE
            );
        }
        else{
            MLV_draw_image(voitureBleuH,x*TAILLE_BRIQUE,(TAILLE-y-1)*TAILLE_BRIQUE+ENTETE_V);
            MLV_draw_text_with_font(
                x*TAILLE_BRIQUE+DECALAGE_NUM_H, (TAILLE-y-1)*TAILLE_BRIQUE+ENTETE_V+DECALAGE_NUM_V,
                str,
                font,
                MLV_COLOR_ANTIQUE_WHITE
            );
        }

    }


    /** On actualise la fenetre pour mettre à jour l'affichage **/
    MLV_actualise_window();

    /** Libération des images **/
    MLV_free_image( voiturePrincipale );
    MLV_free_image( voitureBleuH );
    MLV_free_image( voitureBleuV );
    MLV_free_image( voitureRoseH );
    MLV_free_image( voitureRoseV );
    MLV_free_font( font );

}

/**
 * Affiche la sortie du jeu sur la fenetre
 */
void afficher_sortie(){

    MLV_Image *sortie = MLV_load_image( "../../images/rh/sortie.png" );
    
    /** Redimensionnement de l'image de fond et des briques **/
    MLV_resize_image_with_proportions(sortie, TAILLE_BRIQUE*3, TAILLE_BRIQUE);

    /** Affichage de l'image de fond **/
    MLV_draw_image(sortie,TAILLE*TAILLE_BRIQUE,Y_SORTIE*TAILLE_BRIQUE);

    /** On actualise la fenetre pour mettre à jour l'affichage **/
    MLV_actualise_window();

    /** On libère l'image de sortie **/
    MLV_free_image(sortie);

}

/**
 * Affiche l'intégralité du jeu en appelant chacune des fonctions d'affichage décrites précédemmment
 * Cette fonction est appelée à chaque fois qu'un mouvement est réalisé et sert en somme à actualiser le 
 * contenu de la fenetre
 */
void affichage_graphique(game g){

	/** On fixe la taille de la fenetre grace au nombre de pieces, la taille des briques et l'espace additionnel vertical et horizontal **/
	int width = (TAILLE_BRIQUE*TAILLE)+ENTETE_H, height = (TAILLE_BRIQUE*TAILLE)+ENTETE_V;

    /** On appelle la fonction se chargeant de l'affichage de la grille de jeu **/
	afficher_grille(TAILLE, width, height);

    /** On appelle la fonction se chargeant de l'affichage des voitures sur la grille de jeu **/
    afficher_voitures(g);

    /** On appelle la fonction se chargeant de l'affichage de la sortie sur la grille de jeu **/
    afficher_sortie();

}

/**
 * Identifie l'indice d'une voiture en fonction des coordonées x et y qui lui sont passées en paramètre
 * Si les coordonées correspondent bien aux coordonnées d'une pièce, elle renverra son indice (son numéro)
 * -1 sinon pour indiquer qu'aucune pièce n'existe à ces coordonnées
 */
int identifier_voiture(game g,int x,int y){

    int xmin, xmax, ymin, ymax;
    for (int i = 0; i < TAILLE; ++i)
    {
        xmin=get_x(game_piece(g,i))*TAILLE_BRIQUE;
        xmax=get_x(game_piece(g,i))*TAILLE_BRIQUE+get_width(game_piece(g,i))*TAILLE_BRIQUE;
        ymin=(TAILLE - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+ENTETE_V;
        ymax=(TAILLE - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+get_height(game_piece(g,i))*TAILLE_BRIQUE+ENTETE_V;
        if(x>=xmin && x<=xmax && y>=ymin && y<=ymax){
            return i;
        }
    }

    return -1;
}

/**
 * Affiche des flèches sur les extrémités d'une pièce
 * On traite les cas où la pièce est verticale et où elle ne l'est pas et on place les flèches en conséquence
 */
void afficher_directions(game g, int i){

    int xDir1=0, yDir1=0;
    int xDir2=0, yDir2=0;

    /** Si la pièce est horizontale, on affiche les flèches directionnelles sur la bords horizontaux **/
    if(is_horizontal(game_piece(g,i))){
        xDir1 = get_x(game_piece(g,i))*TAILLE_BRIQUE;
        xDir2 = get_x(game_piece(g,i))*TAILLE_BRIQUE+get_width(game_piece(g,i))*TAILLE_BRIQUE-52;
        yDir1 = (TAILLE - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+ENTETE_V+TAILLE_BRIQUE/3;
        MLV_Image *fGauche = MLV_load_image( "../../images/rh/f_gauche.png" );
        MLV_Image *fDroite = MLV_load_image( "../../images/rh/f_droite.png" );
        MLV_resize_image_with_proportions(fGauche, MLV_get_window_width(), TAILLE_BRIQUE/3);
        MLV_resize_image_with_proportions(fDroite, MLV_get_window_width(), TAILLE_BRIQUE/3);
        MLV_draw_image(fGauche,xDir1,yDir1);
        MLV_draw_image(fDroite,xDir2,yDir1);
        MLV_free_image( fGauche );
    	MLV_free_image( fDroite );
    }
    /** Sur les bords verticaux si la pièce est verticale **/
    else{
        xDir1 = get_x(game_piece(g,i))*TAILLE_BRIQUE+TAILLE_BRIQUE/3;
        yDir1 = (TAILLE - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+ENTETE_V;
        yDir2 = (TAILLE - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+get_height(game_piece(g,i))*TAILLE_BRIQUE+ENTETE_V-52;
        MLV_Image *fHaut = MLV_load_image( "../../images/rh/f_haut.png" );
        MLV_Image *fBas = MLV_load_image( "../../images/rh/f_bas.png" );
        MLV_resize_image_with_proportions(fHaut, TAILLE_BRIQUE/3, MLV_get_window_height());
        MLV_resize_image_with_proportions(fBas, TAILLE_BRIQUE/3, MLV_get_window_height());
        MLV_draw_image(fHaut,xDir1,yDir1);
        MLV_draw_image(fBas,xDir1,yDir2);
        MLV_free_image( fHaut );
    	MLV_free_image( fBas );
    }

}

/**
 * Tant que le jeu n'est pas fini, la fonction va demander à l'utilisateur de cliquer sur une pièce
 * puis d'appuyer sur une flèche directionnelle afin de faire bouger cette pièce
 */
void debut_jeu_graphique(game g, int nbPiece) {

    /**Declararion des variables permettant de récupérer et traiter les informations
    destinées aux mouvements des pièces**/

    MLV_Keyboard_button touche;
    MLV_Keyboard_modifier mode;
    int unicode;

    dir direction;
    int x=0,y=0;
    int num_voiture_clic=0;

    /**Début du jeu. Tant que le jeu n'est pas finit, on continue a demander des informations
    a l'utilisateur**/
    while(!game_over_hr(g)) {

        affichage_graphique(g);
        MLV_wait_mouse(&x, &y);
        num_voiture_clic = identifier_voiture(g,x,y);
        if(num_voiture_clic == -1){
            MLV_draw_text(
                20,20,
                "Aucune pièce sélectionnée : recommencez !",                    
                MLV_COLOR_GREEN
                );
            MLV_actualise_window();
            MLV_wait_seconds(2);
            continue;
        }
        else{
            afficher_directions(g, num_voiture_clic);
            MLV_draw_text(
                20,20,
                "Appuyez sur une touche directionnelle",                    
                MLV_COLOR_GREEN
                );
            MLV_actualise_window();
            MLV_wait_keyboard(&touche, &mode, &unicode);
            switch(touche){
                case MLV_KEYBOARD_UP:
                direction = UP;
                break;

                case MLV_KEYBOARD_DOWN:
                direction = DOWN;
                break;

                case MLV_KEYBOARD_LEFT:
                direction = LEFT;
                break;

                case MLV_KEYBOARD_RIGHT:
                direction = RIGHT;
                break;

                default:
                direction = UP;
            }
            play_move(g,num_voiture_clic,direction,1);
            

        }
        MLV_actualise_window();
        
    }
    /** Lorsque le jeu est fini, on affiche à l'écran une nouvelle image sur laquelle sera superposée le nombre de coups joués
        Pour arriver à ce résultat **/
    MLV_clear_window(MLV_COLOR_BLACK);
    MLV_Image *gameOver = MLV_load_image( "../../images/rh/gameOver.jpg" );
    MLV_resize_image(gameOver, MLV_get_window_width(), MLV_get_window_height());
    MLV_draw_image(gameOver,0,0);
    MLV_Font* fontGameOver = MLV_load_font( "../../fonts/FopiRush.ttf" , 60 );
    MLV_draw_text_with_font(10,MLV_get_window_height()/2-60,
        "Vous avez gagne en %d coups",
        fontGameOver,
        MLV_COLOR_RED,
        game_nb_moves(g));
    MLV_actualise_window();

    /** On libère la font et l'image loadées précédemment **/
    MLV_free_font(fontGameOver);
    MLV_free_image(gameOver);
    MLV_wait_seconds(2);
}


int main(int argc, char* argv[]) {

	/** On fixe la taille de la fenetre grace au nombre de pieces, la taille des briques et l'espace additionnel vertical et horizontal **/
    int width = (TAILLE_BRIQUE*TAILLE)+ENTETE_H, height = (TAILLE_BRIQUE*TAILLE)+ENTETE_V;

    /** On crée la fenetre, vide pour le moment **/
    MLV_create_window( "Rush Hour !", "RushHour", width, height );

    /** On crée le tableau de pièces qui va permettre de construire le jeu **/
    piece *tabP= (piece*)malloc(TAILLE*sizeof(piece));
    tabP[0] = new_piece_rh(0,3,true,true);
    tabP[1] = new_piece_rh(5,2,false,false);
    tabP[2] = new_piece_rh(2,1,true,true);
    tabP[3] = new_piece_rh(3,5,false,true);
    tabP[4] = new_piece_rh(3,2,false,false);
    tabP[5] = new_piece_rh(0,2,false,true);

    /** Création du jeu **/
    game g = new_game_hr(TAILLE,tabP);

    /** On lance le jeu **/
    debut_jeu_graphique(g,TAILLE);

    MLV_free_window();

    /**On detruit le jeu une fois qu'il est fini ainsi que le tableau**/
    delete_game(g);
    free(tabP);

    return 0;

}
