#include "piece.h"
#include "game.h"
#include "stdbool.h"
#include "stdlib.h"
#include "stdio.h"
#include <MLV/MLV_all.h>
#include <string.h>

#define NB_PIECE 10
#define TAILLE_W 4
#define TAILLE_H 5
#define ENTETE_V 100
#define ENTETE_H 0
#define TAILLE_BRIQUE 100
#define DECALAGE_NUM_H TAILLE_BRIQUE/2-10
#define DECALAGE_NUM_V TAILLE_BRIQUE/4
#define X_SORTIE 1.4


/**
 * Vérifie si le jeu est terminé en regardant les coordonées de la pièce principale
 */
bool game_over_ane(cgame g){
  int x = get_x(game_piece(g,0));
  int y = get_y(game_piece(g,0));
    if(x==1 && y==0)
        return true;
    else
        return false;

}

/**
 * Affiche la grille de jeu dans la fenetre
 * On alterne entre des pièces claires et des pièces plus foncées en s'assurant que deux pièces 
 * de la même couleur ne peuvent pas se toucher pour réaliser un cadrillage correct
 */
void afficher_grille(int tailleW, int tailleH, int widthF, int heightF){

    int image_width = widthF, image_height = heightF;
    int brique_width, brique_height;    

    /** Chargement de l'image de fond de jeu **/
    MLV_Image *image_fond = MLV_load_image( "../../images/fond_jeu.png" );

    /** Chargement des images des différents type de briques qui vont constituer le cadrillage **/
    MLV_Image *briqueC = MLV_load_image( "../../images/brique_elementaire_c.png" );
    MLV_Image *briqueF = MLV_load_image( "../../images/brique_elementaire_f.png" );
    
    /** Redimensionnement de l'image de fond et des briques **/
    MLV_resize_image(image_fond, image_width, image_height);
    MLV_resize_image(briqueC, TAILLE_BRIQUE, TAILLE_BRIQUE);
    MLV_resize_image(briqueF, TAILLE_BRIQUE, TAILLE_BRIQUE);
    
    /** Récupération de la taille de l'image de fond et des briques **/
    MLV_get_image_size( image_fond, &image_width, &image_height );
    MLV_get_image_size( briqueC, &brique_width, &brique_height );

    /** Affichage de l'image de fond **/
    MLV_draw_image(image_fond,0,0);

    /** Affichage du cadrillage constitué des deux types de briques **/
    /** On s'occupe de cet affichage ligne par ligne, et on alterne à chaque fois la brique de départ 
        Pour ne pas avoir deux briques de la même couleurs collées l'une à l'autre **/  
    int brique=0;
    for(int i=0; i<tailleH; ++i){
        for(int j=0; j<tailleW; ++j){
            if((i%2)==0){
                if((brique%2)==0)
                    MLV_draw_image(briqueC,j*brique_width,i*brique_height+ENTETE_V);
                else
                    MLV_draw_image(briqueF,j*brique_width,i*brique_height+ENTETE_V);
                brique++;
            }
            else{
                if((brique%2)==0)
                    MLV_draw_image(briqueF,j*brique_width,i*brique_height+ENTETE_V);
                else
                    MLV_draw_image(briqueC,j*brique_width,i*brique_height+ENTETE_V);
                brique++;
            }
        }
    }

    /** On affiche les modifications effectuées **/ 
    MLV_actualise_window();


    /** Libération des images **/
    MLV_free_image( image_fond );
    MLV_free_image( briqueC );
    MLV_free_image( briqueF );

}

/**
 * Affiche les pièces une à une sur la grille de jeu dans la fenetre
 * On traite l'affichage d'une pièce en regardant leur taille ainsi que leur forme
 * On traite aussi l'affichage du numéro de la pièce que l'on superpose à l'image de la pièce
 */
void afficher_pieces(game g){

    /** Chargement et redimensionnement des images correspondant au différents type de voitures **/
    MLV_Image *piece_ane = MLV_load_image( "../../images/ar/piece_2_2_an.png" );
    MLV_resize_image(piece_ane, 200, 200);
    MLV_Image *piece_1_1 = MLV_load_image( "../../images/ar/piece_1_1_an.png" );
    MLV_resize_image(piece_1_1, 100, 100);
    MLV_Image *piece_2_1 = MLV_load_image( "../../images/ar/piece_2_1_an.png" );
    MLV_resize_image(piece_2_1, 200, 100);
    MLV_Image *piece_1_2 = MLV_load_image( "../../images/ar/piece_1_2_an.png" );
    MLV_resize_image(piece_1_2, 100, 200);

    int x=0;
    int y=0;

    MLV_Font* font = MLV_load_font( "../../fonts/8-bit.ttf" , 20 );

    char str[2];

    /** Pour chaque pièce contenue dans le jeu **/
    for(int i=0; i<game_nb_pieces(g); ++i){

      x = get_x(game_piece(g,i));
      y = get_y(game_piece(g,i));
      str[0] = i+'0';
      str[1] = '\0';

      /** On traite différemment les cas suivants :
        -lorsque la voiture est la pièce principale
        -lorsque la pièce est petite et verticale
        -lorsque la pièce est grande et verticale
        -lorsque la pièce est petite et horizontale
        -lorsque la pièce est grande et horizontale
        Et on affiche une image différente dans chaque cas ainsi que son numéro **/
      if (i==0)
      {
        MLV_draw_image(piece_ane,x*TAILLE_BRIQUE,(TAILLE_H-y-2)*TAILLE_BRIQUE+ENTETE_V);
        MLV_draw_text_with_font(
            x*TAILLE_BRIQUE+TAILLE_BRIQUE-10, (TAILLE_H-y-2)*TAILLE_BRIQUE+ENTETE_V+80,
            str,
            font,
            MLV_COLOR_ANTIQUE_WHITE
            );
    }
    else if(!is_horizontal(game_piece(g,i)) && get_height(game_piece(g,i))==2){
       MLV_draw_image(piece_1_2,x*TAILLE_BRIQUE,(TAILLE_H-y-2)*TAILLE_BRIQUE+ENTETE_V);
       MLV_draw_text_with_font(
        x*TAILLE_BRIQUE+DECALAGE_NUM_V*1.5, (TAILLE_H-y-2)*TAILLE_BRIQUE+ENTETE_V+DECALAGE_NUM_H,
        str,
        font,
        MLV_COLOR_ANTIQUE_WHITE
        );
    }
    else if(is_horizontal(game_piece(g,i)) && get_width(game_piece(g,i))==2){
    MLV_draw_image(piece_2_1,x*TAILLE_BRIQUE,(TAILLE_H-y)*TAILLE_BRIQUE+ENTETE_V);
    MLV_draw_text_with_font(
        x*TAILLE_BRIQUE+DECALAGE_NUM_V*3.5, (TAILLE_H-y)*TAILLE_BRIQUE+ENTETE_V+DECALAGE_NUM_H-10,
        str,
        font,
        MLV_COLOR_ANTIQUE_WHITE
        );
    }
    else if(get_width(game_piece(g,i))==1 && get_height(game_piece(g,i))==1){
        MLV_draw_image(piece_1_1,x*TAILLE_BRIQUE,(TAILLE_H-y-1)*TAILLE_BRIQUE+ENTETE_V);
        MLV_draw_text_with_font(
            x*TAILLE_BRIQUE+DECALAGE_NUM_H, (TAILLE_H-y-1)*TAILLE_BRIQUE+ENTETE_V+DECALAGE_NUM_V,
            str,
            font,
            MLV_COLOR_ANTIQUE_WHITE
            );
    }


}


    /** On affiche les modifications effectuées **/ 
MLV_actualise_window();

    /** Libération des images **/
MLV_free_image( piece_ane );
MLV_free_image( piece_1_1 );
MLV_free_image( piece_2_1 );
MLV_free_font( font );

}

/**
 * Affiche la sortie du jeu sur la fenetre
 */
void afficher_sortie(){

    MLV_Image *sortie = MLV_load_image( "../../images/ar/sortie.png" );
    
    /** Redimensionnement de l'image de fond et des briques **/
    MLV_resize_image_with_proportions(sortie,TAILLE_BRIQUE*1.2, TAILLE_BRIQUE*1.2);

    /** Affichage de l'image de fond **/
    MLV_draw_image(sortie,X_SORTIE*TAILLE_BRIQUE,TAILLE_H*TAILLE_BRIQUE+ENTETE_V);

    MLV_actualise_window();

    MLV_free_image(sortie);

}

/**
 * Affiche l'intégralité du jeu en appelant chacune des fonctions d'affichage décrites précédemmment
 * Cette fonction est appelée à chaque fois qu'un mouvement est réalisé et sert en somme à actualiser le 
 * contenu de la fenetre
 */
void affichage_graphique(game g){

    /** On fixe la taille de la fenetre grace au nombre de pieces, la taille des briques et l'espace additionnel vertical et horizontal **/
    int width = (TAILLE_BRIQUE*TAILLE_W)+ENTETE_H, height = (TAILLE_BRIQUE*TAILLE_H)+ENTETE_V+100;

    /** On appel la fonction se chargeant de l'affichage de la grille de jeu **/
    afficher_grille(TAILLE_W,TAILLE_H, width, height);

    /** On appelle la fonction se chargeant de l'affichage des pièces sur la grille de jeu **/
    afficher_pieces(g);

    /** On appelle la fonction se chargeant de l'affichage de la sortie sur la grille de jeu **/
    afficher_sortie();
}

/**
 * Identifie l'indice d'une pièce en fonction des coordonées x et y qui lui sont passées en paramètre
 * Si les coordonées correspondent bien aux coordonnées d'une pièce, elle renverra son indice (son numéro)
 * -1 sinon pour indiquer qu'aucune pièce n'existe à ces coordonnées
 */
int identifier_pieces(game g,int x,int y){

    int xmin, xmax, ymin, ymax;
    for (int i = 0; i < game_nb_pieces(g); ++i)
    {
        xmin=get_x(game_piece(g,i))*TAILLE_BRIQUE;
        xmax=get_x(game_piece(g,i))*TAILLE_BRIQUE+get_width(game_piece(g,i))*TAILLE_BRIQUE;
        ymin=(TAILLE_H - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+ENTETE_V;
        ymax=(TAILLE_H - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+get_height(game_piece(g,i))*TAILLE_BRIQUE+ENTETE_V;
        if(x>=xmin && x<=xmax && y>=ymin && y<=ymax){
            return i;
        }
    }

    return -1;
}

/**
 * Affiche des flèches sur les extrémités d'une pièce
 * On traite les cas où la pièce est verticale et où elle ne l'est pas et on place les flèches en conséquence
 */
void afficher_directions(game g, int i){

    int xDir1=0, yDir1=0;
    int xDir2=0, yDir2=0;

    if(is_horizontal(game_piece(g,i))){
        xDir1 = get_x(game_piece(g,i))*TAILLE_BRIQUE;
        xDir2 = get_x(game_piece(g,i))*TAILLE_BRIQUE+get_width(game_piece(g,i))*TAILLE_BRIQUE-52;
        yDir1 = (TAILLE_H - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+ENTETE_V+TAILLE_BRIQUE/3;
        MLV_Image *fGauche = MLV_load_image( "../../images/rh/f_gauche.png" );
        MLV_Image *fDroite = MLV_load_image( "../../images/rh/f_droite.png" );
        MLV_resize_image_with_proportions(fGauche, MLV_get_window_width(), TAILLE_BRIQUE/3);
        MLV_resize_image_with_proportions(fDroite, MLV_get_window_width(), TAILLE_BRIQUE/3);
        MLV_draw_image(fGauche,xDir1,yDir1);
        MLV_draw_image(fDroite,xDir2,yDir1);
    }
    else{
        xDir1 = get_x(game_piece(g,i))*TAILLE_BRIQUE+TAILLE_BRIQUE/3;
        yDir1 = (TAILLE_H - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+ENTETE_V;
        yDir2 = (TAILLE_H - get_y(game_piece(g,i)) - get_height(game_piece(g,i)))*TAILLE_BRIQUE+get_height(game_piece(g,i))*TAILLE_BRIQUE+ENTETE_V-52;
        MLV_Image *fHaut = MLV_load_image( "../../images/rh/f_haut.png" );
        MLV_Image *fBas = MLV_load_image( "../../images/rh/f_bas.png" );
        MLV_resize_image_with_proportions(fHaut, TAILLE_BRIQUE/3, MLV_get_window_height());
        MLV_resize_image_with_proportions(fBas, TAILLE_BRIQUE/3, MLV_get_window_height());
        MLV_draw_image(fHaut,xDir1,yDir1);
        MLV_draw_image(fBas,xDir1,yDir2);
    }

}

/**
 * Tant que le jeu n'est pas fini, la fonction va demander à l'utilisateur de cliquer sur une pièce
 * puis d'appuyer sur une flèche directionnelle afin de faire bouger cette pièce
 */
void debut_jeu_graphique(game g, int nbPiece) {

    /**Declararion des variables permettant de récupérer et traiter les informations
    destinées aux mouvements des pièces**/

    MLV_Keyboard_button touche;
    MLV_Keyboard_modifier mode;
    int unicode;

    dir direction;
    int x=0,y=0;
    int num_voiture_clic=0;
    /**Début du jeu. Tant que le jeu n'est pas finit, on continue a demander des informations
    a l'utilisateur**/
    while(!game_over_ane(g)) {

        affichage_graphique(g);
        MLV_wait_mouse(&x, &y);
        num_voiture_clic = identifier_pieces(g,x,y);
        if(num_voiture_clic == -1){
            MLV_draw_text(
                20,20,
                "Aucune pièce sélectionnée : recommencez !",                    
                MLV_COLOR_GREEN
                );
            MLV_actualise_window();
            MLV_wait_seconds(2);
            continue;
        }
        else{
            afficher_directions(g, num_voiture_clic);
            MLV_draw_text(
                20,20,
                "Appuyez sur une touche directionnelle",                    
                MLV_COLOR_GREEN
                );
            MLV_actualise_window();
            MLV_wait_keyboard(&touche, &mode, &unicode);
            switch(touche){
                case MLV_KEYBOARD_UP:
                direction = UP;
                break;

                case MLV_KEYBOARD_DOWN:
                direction = DOWN;
                break;

                case MLV_KEYBOARD_LEFT:
                direction = LEFT;
                break;

                case MLV_KEYBOARD_RIGHT:
                direction = RIGHT;
                break;

                default:
                direction = UP;
            }
            play_move(g,num_voiture_clic,direction,1);
            

        }
        MLV_actualise_window();
        
    }

    /** Lorsque le jeu est fini, on affiche à l'écran une nouvelle image sur laquelle sera superposée le nombre de coups joués
        Pour arriver à ce résultat **/
    MLV_clear_window(MLV_COLOR_BLACK);
    MLV_Image *gameOver = MLV_load_image( "../../images/rh/gameOver.jpg" );
    MLV_resize_image(gameOver, MLV_get_window_width(), MLV_get_window_height());
    MLV_draw_image(gameOver,0,0);
    MLV_Font* fontGameOver = MLV_load_font( "../fonts/FopiRush.ttf" , 60 );
    MLV_draw_text_with_font(10,MLV_get_window_height()/2-60,
        "Vous avez gagne en %d coups",
        fontGameOver,
        MLV_COLOR_RED,
        game_nb_moves(g));
    MLV_actualise_window();

    /** On libère la font et l'image loadées précédemment **/
    MLV_free_font(fontGameOver);
    MLV_free_image(gameOver);
    MLV_wait_seconds(2);
}

int main() {

    /** On fixe la taille de la fenetre grace au nombre de pieces, la taille des briques et l'espace additionnel vertical et horizontal **/
    int width = (TAILLE_BRIQUE*TAILLE_W)+ENTETE_H, height = (TAILLE_BRIQUE*TAILLE_H)+ENTETE_V+100;

    /** On crée la fenetre, vide pour le moment **/
    MLV_create_window( "Ane Rouge !", "AneRouge", width, height );

    /** On crée le tableau de pièces qui va permettre de construire le jeu **/
    piece *tabP= (piece*)malloc(NB_PIECE * sizeof(piece));
    tabP[0] = new_piece(1,3,2,2,true,true);
    tabP[1] = new_piece(0,0,1,1,true,true);
    tabP[2] = new_piece(0,1,1,2,true,true);
    tabP[3] = new_piece(0,3,1,2,true,true);
    tabP[4] = new_piece(1,2,2,1,true,true);
    tabP[5] = new_piece(1,2,1,1,true,true);
    tabP[6] = new_piece(2,2,1,1,true,true);
    tabP[7] = new_piece(3,3,1,2,true,true);
    tabP[8] = new_piece(3,1,1,2,true,true);
    tabP[9] = new_piece(3,0,1,1,true,true);

    /** Création du jeu **/
    game g = new_game(4,5,NB_PIECE,tabP); //création du jeu

    /** On lance le jeu **/
    debut_jeu_graphique(g,game_nb_pieces(g));

    MLV_wait_seconds(20);
    MLV_free_window();

    delete_game(g);
    free(tabP);
    return 0;

}
